# medicine_shop_project/mysql_custom_backend.py
from django.db.backends.mysql.base import DatabaseWrapper as MySQLDatabaseWrapper

class DatabaseWrapper(MySQLDatabaseWrapper):
    def check_database_version_supported(self):
        # Allow MariaDB 10.4 to work
        if self.connection.mysql_is_mariadb and self.connection.mysql_version >= (10, 4):
            return
        super().check_database_version_supported()
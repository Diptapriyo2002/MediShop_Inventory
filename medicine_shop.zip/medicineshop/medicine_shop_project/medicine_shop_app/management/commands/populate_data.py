# medicine_shop_app/management/commands/populate_data.py
from django.core.management.base import BaseCommand
from medicine_shop_app.models import Medicine

class Command(BaseCommand):
    help = 'Populates the database with initial medicine data'
    
    def handle(self, *args, **options):
        medicines = [
            {
                'name': 'Paracetamol',
                'brand': 'Cipla',
                'category': 'Pain Relief',
                'unit_price': 5.0,
                'selling_price': 8.0,
                'current_stock': 100,
                'min_stock_alert': 20
            },
            {
                'name': 'Amoxicillin',
                'brand': 'Sun Pharma',
                'category': 'Antibiotic',
                'unit_price': 15.0,
                'selling_price': 25.0,
                'current_stock': 50,
                'min_stock_alert': 15
            },
            {
                'name': 'Atorvastatin',
                'brand': 'Dr. Reddy\'s',
                'category': 'Cholesterol',
                'unit_price': 20.0,
                'selling_price': 35.0,
                'current_stock': 30,
                'min_stock_alert': 10
            }
        ]
        
        for medicine_data in medicines:
            medicine, created = Medicine.objects.get_or_create(
                name=medicine_data['name'],
                defaults=medicine_data
            )
            
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Successfully created {medicine.name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'{medicine.name} already exists')
                )
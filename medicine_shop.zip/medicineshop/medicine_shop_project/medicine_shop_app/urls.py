from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('add_medicine/', views.add_medicine, name="add_medicine"),
    path('purchase/', views.purchase, name="purchase"),
    path('sale/', views.sale, name="sale"),
    path('reports/', views.reports, name="reports"),
    path('api/medicine/<int:medicine_id>/', views.get_medicine, name="get_medicine"),
]
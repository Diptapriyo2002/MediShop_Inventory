# medicine_shop_app/views.py
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib import messages
from django.db.models import Sum, F, Q  # Add Q here
from django.utils import timezone
from .models import Medicine, Purchase, Sale
from .forms import MedicineForm, PurchaseForm, SaleForm

# views.py
def index(request):
    medicines = Medicine.objects.all()
    
    # Get search query
    search_query = request.GET.get('q')
    category_filter = request.GET.get('category')
    stock_status = request.GET.get('stock_status')
    
    # Apply search filters
    if search_query:
        medicines = medicines.filter(
            Q(name__icontains=search_query) |  # Use Q instead of models.Q
            Q(brand__icontains=search_query) |
            Q(category__icontains=search_query)
        )
    
    # Apply category filter
    if category_filter:
        medicines = medicines.filter(category=category_filter)
    
    # Apply stock status filter
    if stock_status:
        if stock_status == 'low':
            medicines = medicines.filter(current_stock__lte=F('min_stock_alert'), current_stock__gt=0)
        elif stock_status == 'out':
            medicines = medicines.filter(current_stock=0)
        elif stock_status == 'in_stock':
            medicines = medicines.filter(current_stock__gt=F('min_stock_alert'))
    
    # Get all unique categories for filter dropdown
    categories = Medicine.objects.values_list('category', flat=True).distinct().order_by('category')
    
    total_medicines = medicines.count()
    
    # Calculate total inventory value
    total_value = sum(medicine.unit_price * medicine.current_stock for medicine in medicines)
    
    # Get low stock medicines (for alert section)
    low_stock_medicines = Medicine.objects.filter(current_stock__lte=F('min_stock_alert'), current_stock__gt=0)
    
    context = {
        'medicines': medicines,
        'total_medicines': total_medicines,
        'total_value': total_value,
        'low_stock_medicines': low_stock_medicines,
        'categories': categories,
    }
    return render(request, 'medicine_shop_app/index.html', context)

def add_medicine(request):
    if request.method == 'POST':
        form = MedicineForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Medicine added successfully!')
            return redirect('index')
    else:
        form = MedicineForm()
    
    return render(request, 'medicine_shop_app/add_medicine.html', {'form': form})

def purchase(request):
    # Get medicine_id from URL parameter for quick purchase
    medicine_id = request.GET.get('medicine_id')
    initial = {}
    
    if medicine_id:
        try:
            medicine = Medicine.objects.get(id=medicine_id)
            initial = {
                'medicine': medicine,
                'unit_cost': medicine.unit_price
            }
        except Medicine.DoesNotExist:
            pass
    
    if request.method == 'POST':
        form = PurchaseForm(request.POST)
        if form.is_valid():
            purchase = form.save(commit=False)
            
            # Update medicine stock
            medicine = purchase.medicine
            medicine.current_stock += purchase.quantity
            medicine.save()
            
            # Calculate total cost
            purchase.total_cost = purchase.quantity * purchase.unit_cost
            purchase.save()
            
            messages.success(request, 'Purchase recorded successfully!')
            return redirect('index')
    else:
        form = PurchaseForm(initial=initial)
    
    return render(request, 'medicine_shop_app/purchase.html', {'form': form})

def sale(request):
    # Get medicine_id from URL parameter for quick sale
    medicine_id = request.GET.get('medicine_id')
    initial = {}
    
    if medicine_id:
        try:
            medicine = Medicine.objects.get(id=medicine_id)
            initial = {
                'medicine': medicine,
                'unit_price': medicine.selling_price
            }
        except Medicine.DoesNotExist:
            pass
    
    if request.method == 'POST':
        form = SaleForm(request.POST)
        if form.is_valid():
            sale = form.save(commit=False)
            
            # Check if enough stock is available
            medicine = sale.medicine
            if medicine.current_stock < sale.quantity:
                form.add_error('quantity', 'Not enough stock available')
                return render(request, 'medicine_shop_app/sale.html', {'form': form})
            
            # Update medicine stock
            medicine.current_stock -= sale.quantity
            medicine.save()
            
            # Calculate total amount
            sale.total_amount = sale.quantity * sale.unit_price
            sale.save()
            
            messages.success(request, 'Sale recorded successfully!')
            return redirect('index')
    else:
        form = SaleForm(initial=initial)
    
    return render(request, 'medicine_shop_app/sale.html', {'form': form})

def reports(request):
    # Calculate total purchases
    total_purchases = Purchase.objects.aggregate(total=Sum('total_cost'))['total'] or 0
    
    # Calculate total sales
    total_sales = Sale.objects.aggregate(total=Sum('total_amount'))['total'] or 0
    
    # Calculate profit
    profit = total_sales - total_purchases
    
    # Get recent purchases and sales
    recent_purchases = Purchase.objects.select_related('medicine').order_by('-purchase_date')[:10]
    recent_sales = Sale.objects.select_related('medicine').order_by('-sale_date')[:10]
    
    context = {
        'total_purchases': total_purchases,
        'total_sales': total_sales,
        'profit': profit,
        'recent_purchases': recent_purchases,
        'recent_sales': recent_sales,
    }
    return render(request, 'medicine_shop_app/reports.html', context)

def get_medicine(request, medicine_id):
    try:
        medicine = Medicine.objects.get(id=medicine_id)
        return JsonResponse({
            'unit_price': medicine.unit_price,
            'selling_price': medicine.selling_price,
            'current_stock': medicine.current_stock
        })
    except Medicine.DoesNotExist:
        return JsonResponse({'error': 'Medicine not found'}, status=404)
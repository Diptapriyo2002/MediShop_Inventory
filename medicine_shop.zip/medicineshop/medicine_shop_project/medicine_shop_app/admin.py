from django.contrib import admin
from .models import Medicine, Purchase, Sale

# Register your models here.


@admin.register(Medicine)
class MedicineAdmin(admin.ModelAdmin):
    list_display = ('name', 'brand', 'category', 'current_stock', 'unit_price', 'selling_price')
    list_filter = ('category', 'brand')
    search_fields = ('name', 'brand')

@admin.register(Purchase)
class PurchaseAdmin(admin.ModelAdmin):
    list_display = ('medicine', 'supplier_name', 'quantity', 'unit_cost', 'total_cost', 'purchase_date')
    list_filter = ('purchase_date', 'supplier_name')
    search_fields = ('medicine__name', 'supplier_name')

@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    list_display = ('medicine', 'customer_name', 'quantity', 'unit_price', 'total_amount', 'sale_date')
    list_filter = ('sale_date',)
    search_fields = ('medicine__name', 'customer_name')
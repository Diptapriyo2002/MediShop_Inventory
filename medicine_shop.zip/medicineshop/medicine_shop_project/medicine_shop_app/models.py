# medicine_shop_app/models.py (update)
from django.db import models

class Medicine(models.Model):
    name = models.CharField(max_length=200)
    brand = models.CharField(max_length=100)
    category = models.CharField(max_length=100)
    unit_price = models.FloatField()
    selling_price = models.FloatField()
    current_stock = models.IntegerField(default=0)
    min_stock_alert = models.IntegerField(default=10)
    expiry_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('name', 'brand')  # This prevents duplicate medicines
        
    def __str__(self):
        return self.name

class Purchase(models.Model):
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE, related_name="purchases")
    supplier_name = models.CharField(max_length=200)
    quantity = models.IntegerField()
    unit_cost = models.FloatField()
    total_cost = models.FloatField()
    purchase_date = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.medicine.name} - {self.quantity} units"

class Sale(models.Model):
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE, related_name="sales")
    customer_name = models.CharField(max_length=200, blank=True, null=True)
    quantity = models.IntegerField()
    unit_price = models.FloatField()
    total_amount = models.FloatField()
    sale_date = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.medicine.name} - {self.quantity} units"